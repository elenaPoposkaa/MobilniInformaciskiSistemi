class Clothes {
  int id;
  String name;
  String img;
  String description;
  int price;

  Clothes({ required this.id, required this.name, required this.img, required this.description, required this.price});
}